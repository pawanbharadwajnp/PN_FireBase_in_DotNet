﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PN_Firebase.Helpers
{
    public static class GeoCalculator
    {
        public const double EarthRadius = 6371; // Earth's radius in kilometers

        public static double ToRadians(double degrees)
        {
            return degrees * Math.PI / 180;
        }

        public static double Distance(double lat1, double lon1, double lat2, double lon2)
        {
            //var dLat = ToRadians(lat2 - lat1);
            //var dLon = ToRadians(lon2 - lon1);

            //var a = Math.Sin(dLat / 2) * Math.Sin(dLat / 2) +
            //        Math.Cos(ToRadians(lat1)) * Math.Cos(ToRadians(lat2)) *
            //        Math.Sin(dLon / 2) * Math.Sin(dLon / 2);

            //var c = 2 * Math.Atan2(Math.Sqrt(a), Math.Sqrt(1 - a));


            //var distance = EarthRadius * c;
            //distance *= 1.05; // add 10% increase
            //return distance;


            var a = 6378137; // semi-major axis of the Earth's ellipsoid in meters (WGS 84)
            var b = 6356752.314245; // semi-minor axis of the Earth's ellipsoid in meters (WGS 84)
            var f = (a - b) / a; // flattening of the Earth's ellipsoid
            var L = (lon2 - lon1) * Math.PI / 180;
            var U1 = Math.Atan((1 - f) * Math.Tan(lat1 * Math.PI / 180));
            var U2 = Math.Atan((1 - f) * Math.Tan(lat2 * Math.PI / 180));
            var sinU1 = Math.Sin(U1);
            var cosU1 = Math.Cos(U1);
            var sinU2 = Math.Sin(U2);
            var cosU2 = Math.Cos(U2);
            var λ = L;
            var λp = 2 * Math.PI;
            var iterLimit = 20;
            var sinLambda = 0.0;
            var cosLambda = 0.0;
            var sinSigma = 0.0;
            var cosSigma = 0.0;
            var sigma = 0.0;
            var sinAlpha = 0.0;
            var cosSqAlpha = 0.0;
            var cos2SigmaM = 0.0;
            var C = 0.0;
            while (Math.Abs(λ - λp) > 1e-12 && --iterLimit > 0)
            {
                sinLambda = Math.Sin(λ);
                cosLambda = Math.Cos(λ);
                sinSigma = Math.Sqrt((cosU2 * sinLambda) * (cosU2 * sinLambda) +
                    (cosU1 * sinU2 - sinU1 * cosU2 * cosLambda) *
                    (cosU1 * sinU2 - sinU1 * cosU2 * cosLambda));
                if (sinSigma == 0)
                {
                    return 0; // coincident points
                }
                cosSigma = sinU1 * sinU2 + cosU1 * cosU2 * cosLambda;
                sigma = Math.Atan2(sinSigma, cosSigma);
                sinAlpha = cosU1 * cosU2 * sinLambda / sinSigma;
                cosSqAlpha = 1 - sinAlpha * sinAlpha;
                cos2SigmaM = cosSigma - 2 * sinU1 * sinU2 / cosSqAlpha;
                if (double.IsNaN(cos2SigmaM))
                {
                    cos2SigmaM = 0; // equatorial line: cosSqAlpha=0 (§6)
                }
                C = f / 16 * cosSqAlpha * (4 + f * (4 - 3 * cosSqAlpha));
                λp = λ;
                λ = L + (1 - C) * f * sinAlpha *
                    (sigma + C * sinSigma *
                    (cos2SigmaM + C * cosSigma *
                    (-1 + 2 * cos2SigmaM * cos2SigmaM)));
            }
            if (iterLimit == 0)
            {
                return double.NaN; // formula failed to converge
            }
            var uSq = cosSqAlpha * (a * a - b * b) / (b * b);
            var A = 1 + uSq / 16384 * (4096 + uSq * (-768 + uSq * (320 - 175 * uSq)));
            var B = uSq / 1024 * (256 + uSq * (-128 + uSq * (74 - 47 * uSq)));
            var deltaSigma =
                B * sinSigma * (cos2SigmaM + B / 4 *
                (cosSigma * (-1 + 2 * cos2SigmaM * cos2SigmaM) - B / 6 * cos2SigmaM *
                (-3 + 4 * sinSigma * sinSigma) *
                (-3 + 4 * cos2SigmaM * cos2SigmaM)));
            var s = b * A * (sigma - deltaSigma) / 1000;

            s *= 1.15; // add 10% increase
            return s;
        }
    }

}
