﻿using BNPL_ENV.Model.Functionality;
using BNPL_ENV.Model;
using PN_Firebase.Services.Interfaces;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using PN_Firebase.Models.Enums;
using System;
using Microsoft.Extensions.Options;
using PN_Firebase.Models;
using System.Net.Http.Json;
using System.Net.Http.Headers;
using PN_Firebase.Helpers;

namespace PN_Firebase.Services.Core
{
    public class FirebaseService : IFirebaseService
    {
        private HttpClient _HttpClient;
        private readonly FirebaseConfigs _configs;

        public FirebaseService(IOptions<FirebaseConfigs> configs)
        {
            _configs = configs.Value;
        }

        private void InitServiceClient(SERVICE_CLIENT_TYPE _ServiceClientType)
        {
            string BASE_URL = _ServiceClientType == SERVICE_CLIENT_TYPE.FCM ? _configs.BASE_URL_FCM : _configs.BASE_URL_MAPS;
            _HttpClient = new HttpClient { BaseAddress = new Uri(BASE_URL) };
        }

        public async Task<object> SendNotification(UserNotifications _UserNotifications)
        {
            if (_HttpClient == null) { InitServiceClient(SERVICE_CLIENT_TYPE.FCM); }
            object Obj = await NotifyAsync(_UserNotifications);

            return (Obj);
        }

        public async Task<object> VerifyGooglePlaces(string placesID, bool getRawData = false)
        {
            if (_HttpClient == null) { InitServiceClient(SERVICE_CLIENT_TYPE.MAPS); }
            object Obj = await VerifyGooglePlacesAPI(placesID, getRawData);

            return (Obj);
        }

        public async Task<object> GetDistance(List<MerchantStores> merchantsStores, decimal latitude, decimal longitude)
        {
            if (_HttpClient == null) { InitServiceClient(SERVICE_CLIENT_TYPE.MAPS); }

            try
            {
                string source = null, destination = null;
                foreach (var _StoreLocal in merchantsStores)
                {
                    if (_StoreLocal != null && _StoreLocal.StoreAddresses != null)
                    {
                        if (_StoreLocal.StoreAddresses.Locations != null)
                        {
                            if (!string.IsNullOrEmpty(_StoreLocal.StoreAddresses.Locations.Latitude) && !string.IsNullOrEmpty(_StoreLocal.StoreAddresses.Locations.Longitude))
                            {
                                var sourceStringLocal = string.Format("{0},{1}", latitude.ToString(), longitude.ToString());
                                source = source != null ? string.Format("{0}|{1}", source, sourceStringLocal) : sourceStringLocal;

                                //var destStringLocal = string.Format("{0},{1}", _StoreLocal.Latitude, _StoreLocal.Longitude);
                                //destination = destination != null ? string.Format("{0}|{1}", destination, destStringLocal) : destStringLocal;

                                if (_configs.IsGoogleEnabled)
                                {
                                    var destStringLocal = string.Format("{0},{1}", _StoreLocal.StoreAddresses.Locations.Latitude, _StoreLocal.StoreAddresses.Locations.Longitude);
                                    destination = destination != null ? string.Format("{0}|{1}", destination, destStringLocal) : destStringLocal;
                                }
                                else
                                {
                                    double distance = GeoCalculator.Distance((double)latitude, (double)longitude, double.Parse(_StoreLocal.StoreAddresses.Locations.Latitude), double.Parse(_StoreLocal.StoreAddresses.Locations.Longitude));
                                    _StoreLocal.Distance = decimal.Parse((distance).ToString("0.00"));
                                    _StoreLocal.Duration = ((decimal)distance).ToString("0 mins");
                                }
                            }
                        }
                    }
                }
                if (_configs.IsGoogleEnabled)
                {
                    // var response = await _HttpClient.GetAsync("api/distancematrix/json?destinations=" + source + "&origins=" + destination + Credentials.GoogleAPIKey);
                    var response = await _HttpClient.GetAsync("api/distancematrix/json?origins=" + source + "&destinations=" + destination + "&key=" + _configs.GoogleAPIKey);
                    object obj = await ResponseHandler<FCM_DistancematricApimodel>(response);

                    if (obj != null && obj is FCM_DistancematricApimodel)
                    {

                        var GoogleRespons = (FCM_DistancematricApimodel)obj;

                        for (int i = 0; merchantsStores.Count > i && GoogleRespons.Rows.Count > i; i++)
                        {
                            string[] distancevalue = Array.Empty<string>();
                            distancevalue = GoogleRespons.Rows[i].Elements[i].Distance.Text.Split(' ');
                            decimal distance = Convert.ToDecimal(distancevalue[0]);
                            merchantsStores[i].Distance = distance;
                            merchantsStores[i].Duration = GoogleRespons.Rows[i].Elements[i].Duration.text;

                        }
                    }
                }
                return merchantsStores;
            }
            catch (Exception ex) {}
            return null;
        }



        public async Task<object> Getofferdistance(List<Offers> Offers, decimal latitude, decimal longitude)
        {
            if (_HttpClient == null) { InitServiceClient(SERVICE_CLIENT_TYPE.MAPS); }
            object Obj = await Getdistanceforoffer(Offers, latitude, longitude);
            return (Obj);
        }

        async Task<object> Getdistanceforoffer(List<Offers> offerlist, decimal latitude, decimal longitude)
        {
            string source = null, destination = null;

            foreach (var _offerlist in offerlist)
            {
                var sourceStringLocal = string.Format("{0},{1}", latitude.ToString(), longitude.ToString());
                source = source != null ? string.Format("{0}|{1}", source, sourceStringLocal) : sourceStringLocal;
                if (_configs.IsGoogleEnabled)
                {
                    if (_offerlist.Merchant != null)
                    {
                        var destStringLocal = string.Format("{0},{1}", _offerlist.Merchant.Latitude.ToString(), _offerlist.Merchant.Longitude.ToString());
                        destination = destination != null ? string.Format("{0}|{1}", destination, destStringLocal) : destStringLocal;

                    }
                }
                else
                {
                    double distance = GeoCalculator.Distance((double)latitude, (double)longitude, double.Parse(_offerlist.Merchant.Latitude), double.Parse(_offerlist.Merchant.Longitude));
                    _offerlist.Merchant.Distance = decimal.Parse((distance).ToString("0.00"));
                    _offerlist.Merchant.Duration = ((decimal)distance).ToString("0 mins");
                }
            }
            if (_configs.IsGoogleEnabled)
            {
                var response = await _HttpClient.GetAsync("api/distancematrix/json?origins=" + source + "&destinations=" + destination + "&key=" + _configs.GoogleAPIKey);
                object obj = await ResponseHandler<FCM_DistancematricApimodel>(response);

                if (obj != null && obj is FCM_DistancematricApimodel)
                {

                    FCM_DistancematricApimodel googledistance = (FCM_DistancematricApimodel)obj;

                    for (int i = 0; offerlist.Count > i && googledistance.Rows.Count > i; i++)
                    {
                        string[] distancevalue = Array.Empty<string>();
                        distancevalue = googledistance.Rows[i].Elements[i].Distance.Text.Split(' ');
                        decimal distance = Convert.ToDecimal(distancevalue[0]);
                        offerlist[i].Merchant.Distance = distance;
                        offerlist[i].Merchant.Duration = googledistance.Rows[i].Elements[i].Duration.text;
                    }

                    return offerlist;
                }
            }

            return offerlist;
        }


        private void GetRequestHeaders(UserNotifications userNotification)
        {
            if (userNotification.MerchantPushTokensList!=null)
            {
                _HttpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("key", "=" + _configs.MerchantSecretKey);

                _HttpClient.DefaultRequestHeaders.Remove("Sender");
                _HttpClient.DefaultRequestHeaders.Add("Sender", "id=" + _configs.MerchantSenderID);

            }
            else
            {
                _HttpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("key", "=" + _configs.SecretKey);

            _HttpClient.DefaultRequestHeaders.Remove("Sender");
            _HttpClient.DefaultRequestHeaders.Add("Sender", "id=" + _configs.SenderID);
            }

        }
        async Task<object> ResponseHandler<T>(HttpResponseMessage response, HttpContent content = null, string data = null)
        {
            content = (content == null) ? response.Content : content;

            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                if (content.Headers.ContentLength > 0 || data != null)
                {
                    var dataAsString = !string.IsNullOrEmpty(data) ? data : await content.ReadAsStringAsync();

                    try
                    {
                        if (typeof(T) == typeof(StatusReply))
                        {
                            StatusReply replyModel = Newtonsoft.Json.JsonConvert.DeserializeObject<StatusReply>(dataAsString); ;
                            if (replyModel == null || replyModel.StatusCode <= 1)
                                return null;
                        }
                        return Newtonsoft.Json.JsonConvert.DeserializeObject<T>(dataAsString);

                    }
                    catch (Exception exception)
                    {
                        Console.WriteLine(exception.Message);
                        if (typeof(T) == typeof(StatusReply))
                        {
                            return null;
                        }
                        return ResponseHandler<StatusReply>(response, content);
                    }
                }
            }
            return null;

        }

        async Task<UserNotifications> NotifyAsync(UserNotifications userNotification)
        {
            try
            {
                FCM_NotifyModel NotifyModel = new FCM_NotifyModel(userNotification);
                GetRequestHeaders(userNotification);

                //var response = await _HttpClient.PostAsJsonAsync("send", NotifyModel);
                var response = await _HttpClient.PostAsJsonAsync("send", NotifyModel);
                object obj = await ResponseHandler<FCM_NotifyResponseModel>(response);

                //LogNow("Send Notification", response.RequestMessage.RequestUri.AbsoluteUri, NotifyModel, obj, response.StatusCode);

                if (obj != null && obj is FCM_NotifyResponseModel)
                {
                    FCM_NotifyResponseModel fCM_NotifyResponseModelLocal = (FCM_NotifyResponseModel)obj;
                    if (fCM_NotifyResponseModelLocal.Success)
                    {
                        userNotification.IsReached = true;
                        return userNotification;
                    }
                }

                userNotification.IsReached = false;
                return userNotification;

            }
            catch (Exception ex)
            {  //No such host is known. (test.oppwa.com: 443)
                if (ex.Message.Contains("No such host is known"))
                {
                    return await NotifyAsync(userNotification);
                }
            }

            userNotification.IsReached = false;
            return userNotification;
        }
        async Task<object> VerifyGooglePlacesAPI(string placeID, bool getRawData = false)
        {
            try
            {
                var response = await _HttpClient.GetAsync("api/place/details/json?fields=opening_hours&place_id=" + placeID + "&key=" + _configs.GoogleAPIKey);
                object obj = await ResponseHandler<FCM_GoogleAPICommonResponse>(response);

                if (obj != null && obj is FCM_GoogleAPICommonResponse)
                {
                    var GoogleCommonResponse = (FCM_GoogleAPICommonResponse)obj;
                    if (GoogleCommonResponse.IsSuccess)
                    {
                        if (GoogleCommonResponse.Result != null)
                        {
                            if (getRawData)
                            {
                                return GoogleCommonResponse.Result;
                            }
                            return GoogleCommonResponse.Result.ToAddress();
                        }
                    }
                }
            }
            catch (Exception ex)
            {

            }

            return null;
        }
    }
}
