﻿using BNPL_ENV.Model.Functionality;
using BNPL_ENV.Model;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PN_Firebase.Services.Interfaces
{
    public interface IFirebaseService
    {
        Task<object> SendNotification(UserNotifications _UserNotifications);
        Task<object> VerifyGooglePlaces(string placesID, bool getRawData = false);
        Task<object> GetDistance(List<MerchantStores> merchantsStores, decimal latitude, decimal longitude);
        Task<object> Getofferdistance(List<Offers> Offers, decimal latitude, decimal longitude);
    }
}
