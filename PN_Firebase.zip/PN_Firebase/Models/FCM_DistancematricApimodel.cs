﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PN_Firebase.Models
{
    public class FCM_DistancematricApimodel
    {
        [JsonProperty(PropertyName = "destination_addresses")]
        public List<string> Destination_addresses { get; set; }

        [JsonProperty(PropertyName = "origin_addresses")]
        public List<string> Origin_addresses { get; set; }

        [JsonProperty(PropertyName = "rows")]
        public List<Row> Rows { get; set; }

        [JsonProperty(PropertyName = "status")]
        public string Status { get; set; }

    }


    public class Row
    {
        [JsonProperty(PropertyName = "elements")]
        public List<Element> Elements { get; set; }
    }

    public class Element
    {
        [JsonProperty(PropertyName = "distance")]
        public Distance Distance { get; set; }

        [JsonProperty(PropertyName = "duration")]
        public Duration Duration { get; set; }

        [JsonProperty(PropertyName = "status")]
        public string Status { get; set; }
    }


    public class Distance
    {
        [JsonProperty(PropertyName = "text")]
        public string Text { get; set; }

        [JsonProperty(PropertyName = "value")]
        public int Value { get; set; }
    }

    public class Duration
    {
        [JsonProperty(PropertyName = "Text")]
        public string text { get; set; }
        [JsonProperty(PropertyName = "value")]
        public int Value { get; set; }
    }


}
