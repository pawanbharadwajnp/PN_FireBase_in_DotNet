﻿using BNPL_ENV.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PN_Firebase.Models
{
    public class FCM_PlacesAPIModel
    {
        public List<FCM_PlacesAddressComponentModel> Address_components { get; set; }
        public FCM_PlacesGeometryModel Geometry { get; set; }
        public string Adr_address { get; set; }
        public string Formatted_address { get; set; }
        public string Icon { get; set; }
        public string Name { get; set; }
        public string Reference { get; set; }
        public string Place_id { get; set; }
        public string Url { get; set; }
        public string Utc_offset { get; set; }
        public string Vicinity { get; set; }
        public string Status { get; set; }

        public string[] Types { get; set; }
        public Opening_Hours opening_hours { get; set; }

        public bool IsSuccess
        {
            get
            {
                if (Status != null && Status.Equals("OK", StringComparison.CurrentCultureIgnoreCase))
                {
                    return true;
                }
                return false;
            }
        }

        public Addresses ToAddress(Addresses building = null)
        {
            if (building == null) { building = new Addresses(); }
            if (Name != null) { building.Name = Name; }
            foreach (FCM_PlacesAddressComponentModel _item in Address_components)
            {
                building.Name = Name;
                building.AddressLine1 = string.Format("{0}, {1}", _item.Area, _item.Street);
                building.AddressLine2 = _item.Landmark;
            }

            if (Geometry != null)
            {
                if (Geometry.Location != null)
                {
                    building.Locations = new Locations
                    {
                        Latitude = Geometry.Location.Lat.ToString(),
                        Longitude = Geometry.Location.Lng.ToString(),
                        CreatedAt = DateTime.Now,
                        ID = 0,
                        Name = building.Name
                    };
                }
            }

            return building;
        }
    }

    public class FCM_PlacesAddressComponentModel
    {
        public string Long_name { get; set; }
        public string Short_name { get; set; }
        public string[] Types { get; set; }

        public bool IsTypeAvailable(string typeString)
        {
            foreach (string _item in Types)
            {
                if (_item.Equals(typeString, StringComparison.CurrentCultureIgnoreCase))
                {
                    return true;
                }
            }
            return false;
        }

        public string Landmark { get { return IsTypeAvailable("neighborhood") ? Long_name : null; } }
        public string Area { get { return IsTypeAvailable("sublocality_level_2") ? Long_name : null; } }
        public string Street { get { return IsTypeAvailable("sublocality_level_1") ? Long_name : null; } }

    }

    public class FCM_PlacesGeometryModel
    {
        public FCM_PlacesLocationModel Location { get; set; }
        public FCM_PlacesViewPortModel Viewport { get; set; }
    }

    public class FCM_PlacesViewPortModel
    {
        public FCM_PlacesLocationModel Northeast { get; set; }
        public FCM_PlacesLocationModel Southwest { get; set; }
    }

    public class FCM_PlacesLocationModel
    {
        public decimal Lat { get; set; }
        public decimal Lng { get; set; }
    }

    public class Opening_Hours
    {
        public bool open_now { get; set; }
        public List<Period> periods { get; set; }
        public List<string> weekday_text { get; set; }
    }

    public class Period
    {
        public Close close { get; set; }
        public Open open { get; set; }
    }

    public class Open
    {
        public string date { get; set; }
        public int day { get; set; }
        public string time { get; set; }
    }

    public class Close
    {
        public string date { get; set; }
        public int day { get; set; }
        public string time { get; set; }
        public bool? truncated { get; set; }
    }
}
