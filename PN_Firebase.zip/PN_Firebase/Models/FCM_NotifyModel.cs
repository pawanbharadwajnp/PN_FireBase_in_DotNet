﻿
using Amazon.SimpleEmail.Model;
using BNPL_ENV.Model.Functionality;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PN_Firebase.Models
{
    public class FCM_NotifyModel
    {
        public FCM_NotifyModel() { }
        public FCM_NotifyModel(UserNotifications userNotification)
        {
            Registration_ids = new string[] { };
            if(userNotification.MerchantPushTokensList != null)
                Registration_ids = userNotification.MerchantPushTokensList != null ? userNotification.MerchantPushTokensList.Select(UPN => UPN.PushToken).ToArray() : new string[] { };
            else
            Registration_ids = userNotification.UserPushTokensList != null ? userNotification.UserPushTokensList.Select(UPN => UPN.PushToken).ToArray() : new string[] { };

            Notification = new FCM_Notification(userNotification.Notifications);
            IDictionary<string, string> dictinoryData = userNotification.Notifications.Data;
            Data = dictinoryData;
            //foreach (var data in Data)
            //{
            //    if (Data == null) { Data = new JObject(); }
            //    Data.Add(new JObject(data));
            //}
        }
        [JsonProperty(PropertyName = "registration_ids")]
        public string[] Registration_ids { get; set; }

        [JsonProperty(PropertyName = "notification")]
        public FCM_Notification Notification { get; set; }

        [JsonProperty(PropertyName = "data")]
        public IDictionary<string,string> Data { get; set; }

    }

    public class FCM_Notification
    {
        public FCM_Notification() { }
        public FCM_Notification(Notifications notifications)
        {
            if (notifications != null)
            {
                Body = notifications.Message;
                Title = notifications.Title;
                Icon = notifications.IconLink != null ? notifications.IconLink : null;
                Image = notifications.ImageLink != null ? notifications.ImageLink : null;
            }
        }
        [JsonProperty(PropertyName = "body")]
        public string Body { get; set; }
        [JsonProperty(PropertyName = "title")]
        public string Title { get; set; }
        [JsonProperty(PropertyName = "icon")]
        public string Icon { get; set; }

        [JsonProperty(PropertyName = "image")]
        public string Image { get; set; }
    }
}
