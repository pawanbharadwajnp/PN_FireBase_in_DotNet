﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PN_Firebase.Models
{
    public class FCM_NotifyResponseModel
    {
        //{"multicast_id":1689721614549191954,"success":0,"failure":1,"canonical_ids":0,"results":[{"error":"NotRegistered"}]}
        [JsonProperty(PropertyName = "multicast_id")]
        public string Multicast_id { get; set; }

        [JsonProperty(PropertyName = "success")]
        public bool Success { get; set; }

        [JsonProperty(PropertyName = "failure")]
        public bool Failure { get; set; }

        [JsonProperty(PropertyName = "canonical_ids")]
        public string Canonical_ids { get; set; }

        [JsonProperty(PropertyName = "results")]
        public List<Dictionary<string, string>> Results { get; set; }

    }
}
