﻿namespace PN_Firebase.Models.Enums
{
    public enum SERVICE_CLIENT_TYPE : int
    {
        FCM = 1,
        MAPS = 2
    }
}
