﻿namespace PN_Firebase.Models
{
    public class FirebaseConfigs
    {
        public string BASE_URL_FCM { get; set; }
        public string BASE_URL_MAPS { get; set; }
        public bool IsGoogleEnabled { get; set; }
        public string CODE { get; set; }
        public string CATEGORY { get; set; }
        public string SenderID { get; set; }
        public string SecretKey { get; set; }
        public string GoogleAPIKey { get; set; }
        public string MerchantSenderID { get; set; }
        public string MerchantSecretKey { get; set; }
    }
}
