﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PN_Firebase.Models
{
    public class FCM_GoogleAPICommonResponse
    {
        public FCM_PlacesAPIModel Result { get; set; }
        public string Status { get; set; }

        public bool IsSuccess
        {
            get
            {
                if (Status != null && Status.Equals("OK", StringComparison.CurrentCultureIgnoreCase))
                {
                    return true;
                }
                return false;
            }
        }

    }
}
